/* first secret message code work */
var displayName = document.getElementById("secret");   /* variable that stores the secret */
var button = document.getElementById("myButton");  /* variable that stores what the button will do */

button.addEventListener("click", displaySecret);  /* once the button is clicked the message will be displayed */

function displaySecret(){ /* function that stores the first displaySecret */
  var text = document.getElementById("myText").value; /* text that is going to be printed out */
  displayName.innerHTML = text + ", did you know owning a cat or dog is equivalent to recieving 70,000 euros per year as it gives boosted life satisfaction in marriages and friendships. " /* the secret message that will be displayed*/
}

/* second secret message code work */
var displayName2 = document.getElementById("secret1"); /* variable that stores the secret */
var button2 = document.getElementById("myButton1");  /* variable that stores what the button will do */

button2.addEventListener("click", displaySecret2);  /* once the button is clicked the message will be displayed */

function displaySecret2(){ /* function that stores the first displaySecret */
  var text2 = document.getElementById("myText1").value; /* text that is going to be printed out */
  displayName2.innerHTML = text2 + ", did you know that among pet owners, a strong majority of 86% stated that their pets have a positive impact on their mental health. This data was collected through a poll in February 2023."; /* the secret message that will be displayed */
}

