var hellokittyScore = 0;
var kuoromiScore = 0;
var questionCount = 0;

var result = document.getElementById("result");
var restartButton = document.getElementById("restart");

var q1a1 = document.getElementById("q1a1");
var q1a2 = document.getElementById("q1a2");

var q2a1 = document.getElementById("q2a1");
var q2a2 = document.getElementById("q2a2");

var q3a1 = document.getElementById("q3a1");
var q3a2 = document.getElementById("q3a2");

var q4a1 = document.getElementById("q4a1");
var q4a2 = document.getElementById("q4a2");

var q5a1 = document.getElementById("q5a1");
var q5a2 = document.getElementById("q5a2");

q1a1.addEventListener("click", Kuoromi);
q1a2.addEventListener("click", HelloKitty);

q2a1.addEventListener("click", HelloKitty);
q2a2.addEventListener("click", Kuoromi);

q3a1.addEventListener("click", Kuoromi);
q3a2.addEventListener("click", HelloKitty);

q4a1.addEventListener("click", HelloKitty);
q4a2.addEventListener("click", Kuoromi);

q5a1.addEventListener("click", HelloKitty);
q5a2.addEventListener("click", Kuoromi);

function Kuoromi() {
  kuoromiScore += 1;
  questionCount += 1;
  checkQuizDone();
}

function HelloKitty() {
  hellokittyScore += 1;
  questionCount += 1;
  checkQuizDone();
}

function checkQuizDone() {
  if (questionCount == 5) {
    updateResult();
  }
}

function updateResult() {
  if (kuoromiScore >= 4) {
    result.innerHTML = "Your character is Kuoromi!";
  } else if (hellokittyScore >= 4) {
    result.innerHTML = "Your character is Hello Kitty!";
  } else if (kuoromiScore === hellokittyScore) {
    result.innerHTML = "You're a mix of both characters!";
  } else if (kuoromiScore > hellokittyScore) {
    result.innerHTML = "You are mostly Kuoromi, with a touch of Hello Kitty!";
  } else {
    result.innerHTML = "You are mostly Hello Kitty, with a touch of Kuoromi!";
  }

  restartButton.style.display = "block";
}

restartButton.addEventListener("click", restartQuiz); 

function restartQuiz() {
  hellokittyScore = 0;
  kuoromiScore = 0;
  questionCount = 0;

  result.innerHTML = "Your character is...";
  restartButton.style.display = "none";
}