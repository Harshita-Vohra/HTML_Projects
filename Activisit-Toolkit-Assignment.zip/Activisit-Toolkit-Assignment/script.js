/* first javascript code */
var yesScore = 0; /* variable that stores the number of yes */
var noScore = 0; /* variable that stores the number of no */
var questionCount = 0; /* variable that stores the number of questions that have gone by */

var result = document.getElementById("result"); /* variable that prints out the result */
var restartButton = document.getElementById("restart"); /* variable that stores the restart button code */

var q1a1 = document.getElementById("q1a1"); /* variable that stores the q1a1 */
var q1a2 = document.getElementById("q1a2"); /* variable that stores the q1a2 */

var q2a1 = document.getElementById("q2a1"); /* variable that stores the q2a1 */
var q2a2 = document.getElementById("q2a2"); /* variable that stores the q2a2 */

var q3a1 = document.getElementById("q3a1"); /* variable that stores the q3a1 */
var q3a2 = document.getElementById("q3a2"); /* variable that stores the q3a2 */

var q4a1 = document.getElementById("q4a1"); /* variable that stores the q4a1 */
var q4a2 = document.getElementById("q4a2"); /* variable that stores the q4a2 */

var q5a1 = document.getElementById("q5a1"); /* variable that stores the q5a1 */
var q5a2 = document.getElementById("q5a2"); /* variable that stores the q5a2 */

q1a1.addEventListener("click", Yes); /* button that stores Yes value for q1a1 */
q1a2.addEventListener("click", No); /* button that stores No value for q1a2 */

q2a1.addEventListener("click", Yes); /* button that stores Yes value for q2a1 */
q2a2.addEventListener("click", No); /* button that stores No value for q2a2 */

q3a1.addEventListener("click", Yes); /* button that stores Yes value for q3a1 */
q3a2.addEventListener("click", No); /* button that stores No value for q3a2 */

q4a1.addEventListener("click", Yes); /* button that stores Yes value for q3a1 */
q4a2.addEventListener("click", No); /* button that stores No value for q4a2 */

q5a1.addEventListener("click", Yes); /* button that stores Yes value for q3a1 */
q5a2.addEventListener("click", No); /* button that stores No value for q4a2 */

function Yes() { /* function name for when the user clicks the Yes button */
  yesScore += 1; /* increases the variable by +1 everytime they click Yes */
  questionCount += 1; /* increases the variable by +1 everytime they move on to the next question */
  console.log("questionCount = " + questionCount + " yesScore = " + yesScore); /* this is what is displayed in the console with the questionCount increasing and the yesScore increasing as well */
  checkQuizDone(); /* function that checks is if all of the questions have been answered and then displays it  */
}

function No() { /* function name for when the user clicks the No button */
  noScore += 1; /* increases the variable by +1 everytime they click No */
  questionCount += 1; /* increases the variable by +1 everytime they move on to the next question */
  console.log("questionCount = " + questionCount + " noScore = " + noScore); /* this is what is displayed in the console with the questionCount increasing and the noScore increasing as well */
  checkQuizDone(); /* function that checks is if all of the questions have been answered and then displays it  */
}

function checkQuizDone() { /* variable that checks if the questionCount is equal to 5 and then displays a messgase in the console*/
  if (questionCount == 5) {
    console.log("The quiz is done!"); /* this is the message that is displayed in the console when the quiz is finished */
    updateResult(); /* function updates the result to print on the website */
  }
}

function updateResult() { /* function that updates the result */
  if (yesScore >= 4) { /* only does this command if the yescore is greater than or equal to 4 */
    result.innerHTML = "Your result is Yes!"; /* this is what gets printed out on website */
    console.log("Your result is Yes!"); /* this is what gets printed out in the console */
  } else if (noScore >= 4) { /* only does this command if the noscore is greater than or equal to 4 */
    result.innerHTML = "Your result is No!"; /* this is what gets printed out on website */
    console.log("Your result is No!"); /* this is what gets printed out in the console */
  } else { /* only does this command if the user chose (for example) two no and three yes */
    result.innerHTML = "You result is Maybe! (Take your time and think it through)" /* this is what gets printed out on website */
    console.log("Your result is No! (Take your time and think it through)");  /* this is what gets printed out in the console */
  }
}

restartButton.addEventListener("click", restartQuiz);   /* when the restart button is clicked by user the quiz will restart */

function restartQuiz() {  /* restart quiz function */
  yesScore = 0;  /* the variables are all eqaul to 0 once again */
  noScore = 0;
  questionCount = 0;

  result.innerHTML = "Your result is...";  /* this is what is displayed as your result */
  restartButton.style.display = "none";  /* once the button is clicked, nothing is there anymore and waits for user to finish the quiz a second time */

  console.log("Quiz restarted!");  /* prints this message out in the console */

}



